from django.contrib import admin
from mysite.models import Post, Book

# Register your models here.

class PostAdmin(admin.ModelAdmin):
    list_display = ('title', 'slug', 'pub_date')
admin.site.register(Post, PostAdmin)

class BookAdmin(admin.ModelAdmin):
    list_display = ('title','slug', 'author', 'chapter','publication_date','imageur')
admin.site.register(Book, BookAdmin)