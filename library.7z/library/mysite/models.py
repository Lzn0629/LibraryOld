from django.db import models
# Create your models here.
class Book(models.Model):
    title = models.CharField(max_length=100)
    slug = models.CharField(max_length=200)
    author = models.CharField(max_length=50)
    chapter = models.CharField(max_length=50)
    publication_date = models.DateField()
    content = models.TextField()
    imageur = models.URLField(blank=True, null=True)
    
    class Meta: 
        ordering = ('publication_date',) #ordering 指定排序 -pub_date 排序方式    
        
    def __str__(self):
        return self.title
    
class Post(models.Model): #建立類別
    title = models.CharField(max_length=200)
    slug = models.CharField(max_length=200)
    body = models.TextField()
    pub_date = models.DateTimeField(auto_now_add=True) #自動取得時間
    
        
    def __str__(self):
        return self.title
    

